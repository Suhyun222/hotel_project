package com.example.cloudhotel.controller;

import com.example.cloudhotel.service.RoomBasicService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * packageName : com.example.cloudhotel.controller
 * fileName : RoomBasicController
 * author : 605
 * date : 2023-06-29
 * description :
 * 요약 :
 * <p>
 * ===========================================================
 * DATE            AUTHOR             NOTE
 * —————————————————————————————
 * 2023-06-29         605          최초 생성
 */
@RestController
@RequestMapping("/api")
@Slf4j
public class RoomBasicController {
    @Autowired
    RoomBasicService roomBasicService;

}
