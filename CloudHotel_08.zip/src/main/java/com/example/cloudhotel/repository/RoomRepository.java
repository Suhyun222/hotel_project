package com.example.cloudhotel.repository;

import com.example.cloudhotel.dto.RoomDto;
import com.example.cloudhotel.model.Room;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

/**
 * packageName : com.example.cloudhotel.repository
 * fileName : RoomRepository
 * author : 605
 * date : 2023-06-21
 * description :
 * 요약 :
 * <p>
 * ===========================================================
 * DATE            AUTHOR             NOTE
 * —————————————————————————————
 * 2023-06-21         605          최초 생성
 */
@Repository
public interface RoomRepository extends JpaRepository<Room,Integer> {

//    체크 인아웃 + rest 1이상이면 조회하기 + 인원수 + 룸타입 페이징
    @Query(value = "SELECT * from tb_room " +
            "WHERE check_in = :checkIn " +
            "and check_out = :checkOut  " +
            "and people >= :people " +
            "and rest >= 1 ", nativeQuery = true)
    Page<Room> selectByReststPage(@Param("checkIn") String checkIn,
                                  @Param("checkOut") String checkOut,
                                  @Param("people") String people,
                                    Pageable pageable);

    //    체크 인아웃 + rest 1이상이면 조회 + 룸타입 검색하기 + 페이징
    @Query(value = "SELECT * from tb_room " +
            "WHERE check_in = :checkIn " +
            "and check_out = :checkOut  " +
            "and rest >= 1 " +
            "and type_code like %:code%", nativeQuery = true)
    Page<Room> selectByTypeCodePage(@Param("checkIn") String checkIn,
                                  @Param("checkOut") String checkOut,
                                  @Param("code") String code,
                                  Pageable pageable);

//    rest 컬럼 데이터 업데이트
    @Transactional
    @Modifying
    @Query(value = "UPDATE TB_ROOM " +
            "SET rest=(SELECT total - (SELECT count(*) FROM TB_RESERVATION " +
            "where type_code = :typeCode " +
            "and    DELETE_YN = 'N' " +
            "and   check_in = :checkIn) " +
            "as restRoomNumer " +
            "FROM TB_ROOM " +
            "WHERE type_code = :typeCode " +
            "and   check_IN = :checkIn) " +
            "WHERE rno=(select rno from TB_ROOM " +
            "where type_code = :typeCode " +
            "and   check_IN = :checkIn) ", nativeQuery = true)
    int selectAddRest(@Param("checkIn") String checkIn,
            @Param("typeCode") String typeCode);

//    총 가격 계산(룸 + 조식)
    @Query(value = "select rprice + (select eprice*count from tb_etc where eno = :eno) as total_price " +
            "from tb_room " +
            "where type_code = :typeCode", nativeQuery = true)
    int selectTotalPrice(@Param("eno") int eno,
                             @Param("typeCode") String typeCode);

// 해당 날짜에 방 있는지(개수) 조회
    @Query(value = "select count(*) from tb_room " +
            "where check_in = :checkIn " +
            "and type_code = :typeCode " +
            "and rest >=1 " ,nativeQuery = true)
    int selectsearchRoom(@Param("checkIn") String checkIn,
                         @Param("typeCode") String typeCode);

//    쿼리스트링 (IN 이 내부 명령어..?)
//    int countByCheckInAndTypeCodeAndRestGreaterThanEqual(String checkIn,String typeCode,int restnum);

    //    체크 인 + 타입코드 검색하기
    @Query(value = "SELECT * from tb_room " +
            "WHERE check_in = :checkIn " +
            "and type_code like %:typeCode%", nativeQuery = true)
    RoomDto selectByTypeCode(@Param("checkIn") String checkIn,
                             @Param("typeCode") String typeCode);


    //   예약완료시 룸테이블에 insert 쿼리
    @Transactional
    @Modifying
    @Query(value = "INSERT INTO TB_ROOM(RNO,RTYPE,RPRICE,CHECK_IN,TYPE_CODE,TOTAL,REST,PEOPLE) " +
            "VALUES (SQ_ROOM.NEXTVAL, :#{#room.rtype}, " +
            ":#{#room.rprice}, " +
            ":#{#room.checkIn}, " +
            ":#{#room.typeCode}, " +
            ":#{#room.total}, " +
            ":#{#room.rest}, " +
            ":#{#room.people}) "
            , nativeQuery = true
    )
    int insertByRoom(@Param("room") Room room);




}
