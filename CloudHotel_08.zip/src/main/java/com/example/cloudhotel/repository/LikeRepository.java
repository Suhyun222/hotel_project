package com.example.cloudhotel.repository;

import com.example.cloudhotel.model.Like;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
/**
 * packageName : com.example.cloudhotel.repository
 * fileName : LikeRepository
 * author : 605
 * date : 2023-06-27
 * description :
 * 요약 :
 * <p>
 * ===========================================================
 * DATE            AUTHOR             NOTE
 * —————————————————————————————
 * 2023-06-27         605          최초 생성
 */
@Repository
public interface LikeRepository extends JpaRepository<Like, Integer> {
}
