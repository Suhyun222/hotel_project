package com.example.cloudhotel.repository;

import com.example.cloudhotel.dto.RoomDto;
import com.example.cloudhotel.model.RoomBasic;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

/**
 * packageName : com.example.cloudhotel.repository
 * fileName : RoomBasicRepository
 * author : 605
 * date : 2023-06-29
 * description :
 * 요약 :
 * <p>
 * ===========================================================
 * DATE            AUTHOR             NOTE
 * —————————————————————————————
 * 2023-06-29         605          최초 생성
 */
@Repository
public interface RoomBasicRepository extends JpaRepository<RoomBasic,Integer> {

//    룸 베이직 테이블 조회
    @Query(value = "SELECT * FROM TB_ROOM_BASIC " +
            "WHERE type_code = :typeCode",nativeQuery = true)
    RoomDto selectTypeCode(@Param("typeCode") String typeCode);

    RoomBasic findByTypeCode(String typeCode);


}
