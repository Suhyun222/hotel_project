package com.example.cloudhotel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CloudHotelApplication {

	public static void main(String[] args) {
		SpringApplication.run(CloudHotelApplication.class, args);
	}

}
