package com.example.cloudhotel.service;

import com.example.cloudhotel.dto.RoomDto;
import com.example.cloudhotel.model.Room;
import com.example.cloudhotel.model.RoomBasic;
import com.example.cloudhotel.repository.ReservationRepository;
import com.example.cloudhotel.repository.RoomBasicRepository;
import com.example.cloudhotel.repository.RoomRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * packageName : com.example.cloudhotel.service
 * fileName : RoomService
 * author : 605
 * date : 2023-06-21
 * description :
 * 요약 :
 * <p>
 * ===========================================================
 * DATE            AUTHOR             NOTE
 * —————————————————————————————
 * 2023-06-21         605          최초 생성
 */
@Service
public class RoomService {
    @Autowired
    RoomRepository roomRepository;
    @Autowired
    RoomBasicRepository roomBasicRepository;
    @Autowired
    ReservationRepository reservationRepository;

    //    전체조회함수
    public List<Room> findAll(){
        List<Room> list = roomRepository.findAll();
        return list;
    }

//    날짜 + 남은방 개수 + 인원수로 조회하기 + 페이징처리
    public Page<Room> selectByReststPage(String checkIn,
                             String checkOut,
                                         String people,

                             Pageable pageable){
        Page<Room> page = roomRepository.selectByReststPage(checkIn, checkOut,people, pageable);

        return page;
    }

    //    날짜 + 남은방 개수 + 룸코드로 조회 + 페이징처리
    public Page<Room> selectByTypeCodePage(String checkIn,
                                         String checkOut,
                                         String code,
                                         Pageable pageable){
        Page<Room> page = roomRepository.selectByTypeCodePage(checkIn, checkOut,code, pageable);

        return page;
    }

//    rest 컬럼 데이터 업데이트
    public int addRest(String checkIn,
                       String typeCode){
//        룸 테이블에 해당날짜의 데이터가 있는지 조회
        int rsvNum = roomRepository.selectsearchRoom(checkIn, typeCode);
        if(rsvNum == 1){
            int room = roomRepository.selectAddRest(checkIn, typeCode);
            return room;
        }
        else {
            return 0;
        }

    }

//    총 가격 계산(룸 + 조식)
public int selecttotalPrice(int eno,
                                String typeCode){
    int price = roomRepository.selectTotalPrice(eno, typeCode);
    return price;
}

// 룸 타입 + 날짜(체크인) 선택 후 조회시
//    1) 해당 날짜에 남은 방이 1개 이상인 데이터가 있는지 조회
//    2-1) 없으면 room_basic 에 있는 방 정보 보여주기
//    2-2) 있으면 room 테이블의 정보 보여주기
public RoomDto searchAndAdd(String checkIn, String typeCode){
        int yn = roomRepository.selectsearchRoom(checkIn, typeCode);
        if(yn == 0){
            RoomDto roomBasic = roomBasicRepository.selectTypeCode(typeCode);
            return roomBasic;
        }
        else {
            RoomDto room = roomRepository.selectByTypeCode(checkIn, typeCode);
            return room;
        }
    }

    //   예약완료시 룸테이블에 insert 쿼리
    public int insertByRoom(Room room) {
        int roomNum = roomRepository.selectsearchRoom(room.getCheckIn(),room.getTypeCode());
        if (roomNum == 0) {
//        1) 전체 방개수 가져오기 : roomBasic.getTotal()
            RoomBasic roomBasic = roomBasicRepository.findByTypeCode(room.getTypeCode());
//        2) room 에 계산된 정보를 추가 저장(setter)
            room.setTotal(roomBasic.getTotal());
//        3) 남은방개수 : selectAddRest()
//        int restNum = roomRepository.selectAddRest(room.getCheckIn(), room.getTypeCode());
//        room.setRest(restNum);
            int totalNum = room.getTotal();
            int rsvNum2 = reservationRepository.rsvNum(room.getTypeCode(), room.getCheckIn());
            int restNum3 = totalNum - rsvNum2;
            room.setRest(restNum3);
//        4) 방이름 저장
            room.setRtype(roomBasic.getRtype());
//       5) 가격 저장
            room.setRprice(roomBasic.getRprice());
//        6) 인원수 저장
            room.setPeople(roomBasic.getPeople());
            int room2 = roomRepository.insertByRoom(room);
            return room2;
        } else {
            return 0;
        }
    }

//    TODO : 남은방 업데이트 함수 최종
public void updateRest(String checkIn,String typeCode,String checkOut){
    ArrayList<String> al = roomRepository.selectArray(checkIn, checkOut);
    for (int i = 0; i < al.size(); i++) {
        //        룸 테이블에 해당날짜의 데이터가 있는지 조회
        int rsvNum = roomRepository.selectsearchRoom(al.get(i), typeCode);
        if(rsvNum == 1){
//            룸 테이블에 데이터 있으면 REST 레코드 업데이트
            int room = roomRepository.selectAddRest(al.get(i), typeCode);

        }else { int room = 0; }
    }

}

    // TODO  예약완료시 룸테이블에 insert 쿼리 최종
    public void saveRoom(Room room) {

//        체크인 정의
        ArrayList<String> al = roomRepository.selectArray(room.getCheckIn(), room.getCheckOut());
        for (int i = 0; i < al.size(); i++) {

            int roomNum = roomRepository.selectsearchRoom(al.get(i), room.getTypeCode());
            if (roomNum == 0) {
//        1) total 값 가져오기 : roomBasic.getTotal()
                RoomBasic roomBasic = roomBasicRepository.findByTypeCode(room.getTypeCode());
//        2) room 에 계산된 정보를 추가 저장(setter)
                room.setTotal(roomBasic.getTotal());
//        3) 남은방개수 : selectAddRest()
//        int restNum = roomRepository.selectAddRest(room.getCheckIn(), room.getTypeCode());
//        room.setRest(restNum);
                int totalNum = room.getTotal();
                int rsvNum2 = reservationRepository.rsvNum(room.getTypeCode(), al.get(i));
                int restNum3 = totalNum - rsvNum2;
                room.setRest(restNum3);
//        4) 방이름 저장
                room.setRtype(roomBasic.getRtype());
//       5) 가격 저장
                room.setRprice(roomBasic.getRprice());
//        6) 인원수 저장
                room.setPeople(roomBasic.getPeople());
//        7) 체크인 날짜 저장
                room.setCheckIn(al.get(i));

                roomRepository.insertByRoom(room);
            }

        }


    }

}
