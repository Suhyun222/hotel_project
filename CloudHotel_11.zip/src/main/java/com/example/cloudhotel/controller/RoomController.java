package com.example.cloudhotel.controller;

import com.example.cloudhotel.dto.RoomDto;
import com.example.cloudhotel.model.Room;
import com.example.cloudhotel.model.Room;
import com.example.cloudhotel.service.ReservationService;
import com.example.cloudhotel.service.RoomService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * packageName : com.example.cloudhotel.controller
 * fileName : RoomController
 * author : 605
 * date : 2023-06-21
 * description :
 * 요약 :
 * <p>
 * ===========================================================
 * DATE            AUTHOR             NOTE
 * —————————————————————————————
 * 2023-06-21         605          최초 생성
 */
@RestController
@RequestMapping("/api")
@Slf4j
public class RoomController {
    @Autowired
    RoomService roomService;
    @Autowired
    ReservationService reservationService;


    //    전체 조회 함수
    @GetMapping("/room")
    public ResponseEntity<Object> getRoomAll() {
//        에러 처리 : try ~ catch
        try {
//            1) 전체 조회 서비스 함수
            List<Room> list
                    = roomService.findAll();

//          전체 조회 결과가 있으면 데이터 + 성공메세지 전송(출력)
            if(list.isEmpty() == false) {
//                데이터 + 성공메세지 출력(전송)
                return new ResponseEntity<>(list, HttpStatus.OK);
            } else {
//                데이터 없음 , 데이터없음 메세지 출력(전송)
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

        } catch (Exception e) {
            log.debug(e.getMessage()); // 에러발생시 로그 출력
//          서버 에러메세지 전송 (콘솔 출력)
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

//   날짜 + 남은방 개수 + 인원수로 조회하기 + 페이징처리
    @GetMapping("/room/checkIn/checkOut")
    public ResponseEntity<Object> selectcheckInOut( @RequestParam(required = false, defaultValue = "") String checkIn,
                                                    @RequestParam(required = false, defaultValue = "") String checkOut,
                                                    @RequestParam(required = false, defaultValue = "") String people,
                                                    @RequestParam(defaultValue = "0") int page,
                                                    @RequestParam(defaultValue = "5") int size){
        try {
            Pageable pageable = PageRequest.of(page, size);
            Page<Room> room =
                    roomService.selectByReststPage(checkIn, checkOut,people,pageable);

            Map<String, Object> response = new HashMap<>();

//            Map 자료구조에 값 넣기 : put(키, 값);
            response.put("room", room.getContent()); // 룸 객체
            response.put("currentPage", room.getNumber()); // 현재 페이지
            response.put("totalItems", room.getTotalElements()); // 총 개수
            response.put("totalPages", room.getTotalPages()); // 총 페이지

            if (room.isEmpty() == false){
                return  new ResponseEntity<>(response,HttpStatus.OK);
            } else {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

        }catch (Exception e){
            log.debug(e.getMessage());
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    //   날짜 + 남은방 개수 + 룸코드로 조회 페이징처리
    @GetMapping("/room/typeCode/paging")
    public ResponseEntity<Object> selectRtype(@RequestParam(required = false, defaultValue = "") String checkIn,
                                              @RequestParam(required = false, defaultValue = "") String checkOut,
                                              @RequestParam(required = false, defaultValue = "") String code,
                                              @RequestParam(defaultValue = "0") int page,
                                              @RequestParam(defaultValue = "5") int size){
        try {
            //         Pageable 객체에 저장 : page,size 값
//            사용법)  Pageable pageable = PageRequest.of(현재페이지, 페이지당 개수);
            Pageable pageable = PageRequest.of(page, size);

            Page<Room> room =
                    roomService.selectByTypeCodePage(checkIn, checkOut,code, pageable);

            Map<String, Object> response = new HashMap<>();

//            Map 자료구조에 값 넣기 : put(키, 값);
            response.put("room", room.getContent()); // 룸 객체
            response.put("currentPage", room.getNumber()); // 현재 페이지
            response.put("totalItems", room.getTotalElements()); // 총 개수
            response.put("totalPages", room.getTotalPages()); // 총 페이지

            if (room.isEmpty() == false){
                return  new ResponseEntity<>(response,HttpStatus.OK);
            } else {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

        }catch (Exception e){
            log.debug(e.getMessage());
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

//     예약완료시 REST 데이터 갱신 (룸 테이블에 데이터 있을시에만 갱신)
    @PutMapping("/room/update/rest")
    public ResponseEntity<Object> addRest(@RequestParam(required = false, defaultValue = "") String checkIn,
                                          @RequestParam(required = false, defaultValue = "") String typeCode){

            try {
                int room = roomService.addRest(checkIn, typeCode);
                if(room >= 1){
                    return new ResponseEntity<>(HttpStatus.OK);
                }else {
                    return new ResponseEntity<>(HttpStatus.NO_CONTENT);
                }

                }
                catch (Exception e){
                log.debug(e.getMessage());
                return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
            }


    }

    //  TODO  총 가격 계산(룸 + 조식)
    @GetMapping("/room/totalPrice")
    public ResponseEntity<Object> selectTotalPrice(@RequestParam(required = false, defaultValue = "") int eno,
                                          @RequestParam(required = false, defaultValue = "") String typeCode){
        try {
            int price = roomService.selecttotalPrice(eno,typeCode);
            return new ResponseEntity<>(price, HttpStatus.OK);

        }catch (Exception e){
            log.debug(e.getMessage());
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

// 특정 룸 + 특정 날짜 조회시 실행되는 함수
// 룸 테이블에 있는지 조회 -> 없으면 룸베이직 데이터 보여주기 / 있으면 룸 데이터 보여주기
@GetMapping("/room/search/add")
public ResponseEntity<Object> searchAndAdd(@RequestParam(required = false, defaultValue = "") String checkIn,
                                           @RequestParam(required = false, defaultValue = "") String typeCode) {


//        에러 처리 : try ~ catch
    try {
        RoomDto roomDto
                = roomService.searchAndAdd(checkIn, typeCode);

            return new ResponseEntity<>(roomDto, HttpStatus.OK);

    } catch (Exception e) {
        log.debug(e.getMessage()); // 에러발생시 로그 출력
//          서버 에러메세지 전송 (콘솔 출력)
        return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
    }
}

    //    룸테이블 저장 함수 : 예약완료시 실행하기 (룸테이블에 데이터 없을시에만 저장)
    @PostMapping("/room")
    public ResponseEntity<Object> createRoom(@RequestBody Room room
    ) {

        try {
            // 저장 서비스 함수 호출

            int room2 = roomService.insertByRoom(room);

            if(room2 >= 1){
                return new ResponseEntity<>(HttpStatus.OK);
            }else {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

        } catch (Exception e) {
            log.debug(e.getMessage());
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


    // TODO ((남은방 업데이트함수 최종))  예약완료시 REST 데이터 갱신 (룸 테이블에 데이터 있을시에만 갱신)
    @PutMapping("/room/update/array/rest")
    public ResponseEntity<Object> updateRest(@RequestParam(required = false, defaultValue = "") String checkIn,
                                          @RequestParam(required = false, defaultValue = "") String typeCode,
                                            @RequestParam(required = false, defaultValue = "") String checkOut){

        try {
            roomService.updateRest(checkIn, typeCode,checkOut);
                return new ResponseEntity<>(HttpStatus.OK);

        }
        catch (Exception e){
            log.debug(e.getMessage());
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }

    //  TODO  룸테이블 저장 함수 : 예약완료시 실행하기 (룸테이블에 데이터 없을시에만 저장), 체크인/아웃,타입코드 객체형태로 넘겨주기!
    @PostMapping("/room/save/array")
    public ResponseEntity<Object> saveRoom(@RequestBody Room room
    ) {

        try {
            // 저장 서비스 함수 호출

                roomService.saveRoom(room);
                return new ResponseEntity<>(HttpStatus.OK);


        } catch (Exception e) {
            log.debug(e.getMessage());
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

}
