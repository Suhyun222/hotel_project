package com.example.cloudhotel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CloudHotelApplicationTests {

	@Test
	void contextLoads() {
	}

}
